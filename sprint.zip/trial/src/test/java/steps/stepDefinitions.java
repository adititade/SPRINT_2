package steps;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import pages.HomePage;
import utils.BrowserManager;
import utils.QaProps;
import utils.TestDataReader;

import java.util.HashMap;


public class stepDefinitions {
    private WebDriver driver;
    String url;
    HomePage homePage;
    HashMap<String, String> data;
    Scenario scenario;

    public stepDefinitions(BrowserManager browserManager) {
        this.driver = browserManager.getDriver();
    }
    @Before(order = 1)
    public void before(Scenario scenario){
        this.scenario = scenario;
    }

    //First test_SearchBar
    @Given("the user navigates to home page")
    public void the_user_navigates_to_home_page() {
        url = QaProps.getValue("url");
        driver.get(url);
        System.out.println(1/0);
        data = TestDataReader.getData(scenario.getName());
    }
    @When("the user enter the product name")
    public void the_user_enter_the_product_name() {
        homePage = new HomePage(driver);
        homePage.getSearchBox().sendKeys(data.get("TypeValue"));
        homePage.getSearchBox().sendKeys(Keys.ENTER);
    }

    @Then("the products results should be displayed")
    public void the_products_results_should_be_displayed() {
        String text = homePage.getSearchResult().getText();
        Assert.assertEquals(text, data.get("TypeValue"));
    }

    //2nd TestCase_cart
   @When("the user clicked on the displayed products and select add to cart")
    public void the_user_clicked_on_the_displayed_products_and_select_add_to_cart() throws InterruptedException {
       driver.get("https://www.snapdeal.com/");
       homePage = new HomePage(driver);
       homePage.getSearchBox().sendKeys(data.get("TypeValue"));
       homePage.getSearchBox().sendKeys(Keys.ENTER);
       String text = homePage.getSearchResult().getText();
       Assert.assertEquals(text, data.get("TypeValue"));
       homePage.getCart().click();
   }

    @Then("the product is added to cart successfully")
    public void the_product_is_added_to_cart_successfully() {

    }
    //3rd TestCase_Pincode

    @When("the user enter the product name and clicks on the enter your pincode button")
    public void the_user_enter_the_product_name_and_clicks_on_the_enter_your_pincode_button() throws InterruptedException
        {
           homePage = new HomePage(driver);
           homePage.getSearchBox().sendKeys(data.get("TypeValue"));
           homePage.getSearchBox().sendKeys(Keys.ENTER);
           Thread.sleep(2000);
           homePage.getPincode_button().sendKeys("444101");
           homePage.getPincode_button().sendKeys(Keys.ENTER);
       }

    @Then("it will show the  search result  for entered pincode")
    public void it_will_show_the_search_result_for_entered_pincode() throws InterruptedException {
        Thread.sleep(2000);
        homePage.getPincode_check().click();
    }

//4th TestCase_InvalidPincode
@When("the user enter the product name and clicks on the enter your pincode button and trying to enter invalid pincode")
public void the_user_enter_the_product_name_and_clicks_on_the_enter_your_pincode_button_and_trying_to_enter_invalid_pincode() {
    homePage = new HomePage(driver);
    homePage.getSearchBox().sendKeys(data.get("TypeValue"));
    homePage.getSearchBox().sendKeys(Keys.ENTER);
    homePage.getSearchInvalidPincode().sendKeys(data.get("TypeValue"));
    homePage.getSearchInvalidPincode().sendKeys(Keys.ENTER);
    homePage.getSearchResultPincode().click();
    }
    @Then("it will show the related search result is available for entered pincode or not")
public void it_Will_Show_The_Related_Search_Result_Is_Available_For_Entered_Pincode_Or_Not() {
        String text = homePage.getSearchInvalid_button().getText();
        Assert.assertEquals(text, "");
}

    @Then("the products result should be displayed")
    public void theProductsResultShouldBeDisplayed() {
        homePage = new HomePage(driver);

        homePage.getSearchBox().sendKeys(data.get("TypeValue"));
        homePage.getSearchBox().sendKeys(Keys.ENTER);
    }

    @And("the user search for new product")
    public void theUserSearchForNewProduct() throws InterruptedException {
        homePage= new HomePage(driver);
        Thread.sleep(5000);
        homePage.getSearch_multiple().click();
    }

//TestCase4_Ethnic_wear
//    @When("the user enter the product name and click on salwar suit in Ethnic wear for women")
//    public void the_user_enter_the_product_name_and_click_on_salwar_suit_in_ethnic_wear_for_women() {
//        homePage = new HomePage(driver);
//        homePage.getSearchSalwarSuit().click();
//    }
//    @Then("user is navigated to salwar suit section")
//    public void user_is_navigated_to_salwar_suit_section() {
//        String text = homePage.getSearch_resultFound().getText();
//        Assert.assertEquals(text, "We've got 5992 results for womens kurti in Salwar Suit");
//
//    }


}




